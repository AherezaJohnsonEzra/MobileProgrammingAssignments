package com.example.ezrakotlinapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Next Button
        nextButton = findViewById<Button>(R.id.nextBtn)

        nextButton.setOnClickListener{

            val intent = Intent(this,ViewCourseUnits::class.java)
            startActivity(intent)
        }
    }
}